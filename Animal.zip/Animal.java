package Pack;

public class Animal {
    private String Name;
    private int Age;
    private String Species;



    public static int TotalAnimals = 0;

    public Animal(String TheName,String TheSpecies, int TheAge){
        this.Name = TheName;
        this.Age = TheAge;
        this.Species = TheSpecies;
        TotalAnimals++;
    }

    public Animal(){
        System.out.println("\n A new animal was created! \n");
        TotalAnimals++;
    }


    public void setName(String TheName){
        this.Name = TheName;
    }

    public void setAge(int TheAge){
        this.Age = TheAge;
    }

    public void setSpecies(String TheSpecies){
        this.Species = TheSpecies;
    }

    public String getName(){
        return Name;
    }

    public int getAge(){
        return Age;
    }

    public String getSpecies(){
        return Species;

    }

}
