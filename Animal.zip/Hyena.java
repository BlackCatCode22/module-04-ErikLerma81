package Pack;

class Hyena extends Animal {
    private int MaxWeight = 190;

    public Hyena(String name, int age) {
        // Assuming 'Hyena' as the default species for this subclass
        super(name,  "Hyena",age );
    }

    public int getMaxWeight(){
        return MaxWeight;
    }
}
